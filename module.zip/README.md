# MaterialDeck_SWADE
Adds support for Savage Worlds Adventure Edition (SWADE) to [Material Deck](https://github.com/MaterialFoundry/MaterialDeck).

Documentation for this module can be found [here](https://tarmonthir.github.io/MaterialDeck_SWADE).
